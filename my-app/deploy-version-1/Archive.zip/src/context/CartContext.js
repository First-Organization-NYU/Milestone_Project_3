import React, {createContext} from 'react'
import constate from "constate"

export const CartContext = createContext([])

