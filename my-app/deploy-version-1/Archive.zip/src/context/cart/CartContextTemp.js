import {createContext} from 'react'

const CartContextTemp = createContext([])

export default CartContextTemp;