import React, { useState } from 'react';
import {createContainer} from 'constate';

function useCart() {
  const [items, setItems] = useState([]);

  const addToCart = (item) => {
    setItems((prevItems) => [...prevItems, item]);
  };

  const cart = {
    items,
    addToCart,
  };

  return cart;
}

export const CartContainer = createContainer(useCart);
